# Atelier Arquitetura

Aplicação web desenvolvida com React, TypeScript, TanStack Start, Vite e Tailwind CSS.

## Requisitos

- Node.js 20 ou superior
- npm

## Executar localmente

```bash
npm install
npm run dev
```

Abra no navegador o endereço local informado pelo Vite (normalmente http://localhost:3000 ou http://localhost:5173).

## Verificar a compilação de produção

```bash
npm run build
npm run preview
```

## Publicar na Vercel usando GitHub

1. Envie esta pasta para um repositório GitHub.
2. Entre em https://vercel.com/new e importe o repositório.
3. Confirme o preset `TanStack Start` e mantenha as configurações de build detectadas automaticamente.
4. Clique em `Deploy`.
5. Ao terminar, abra o domínio gerado e teste as páginas e a navegação.

O projeto usa Nitro para a implantação do TanStack Start na Vercel. O arquivo `vercel.json` declara o framework para facilitar a detecção da plataforma.
